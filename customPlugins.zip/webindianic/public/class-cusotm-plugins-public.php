<?php

class custom_Plugins_Public {
	
	private $plugin_name;
	
	private $version;

	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
	}
	
	public function enqueue_styles() {
		$options = array(
			"ssl" => array(
				"verify_peer"      => false,
				"verify_peer_name" => false
			)
		);

		$files         = glob( __DIR__ . '/css/*.css' );
		$combined_file = '';
		foreach ( $files as $file ) {
			$combined_file .= file_get_contents( $file, false, stream_context_create( $options ) );
		}
		file_put_contents( __DIR__ . "/css/combined/customplugins-public.css", $combined_file );
		// only the line below should be in production
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/combined/customplugins-public.css', array(), time(), 'all' );
	}

	
	public function enqueue_scripts() {
		$options = array(
			"ssl" => array(
				"verify_peer"      => false,
				"verify_peer_name" => false
			)
		);

		$files         = glob( __DIR__ . '/js/*.js' );

		$combined_file = "(function($){'use strict';$(function(){";
		foreach ( $files as $file ) {
			$combined_file .= file_get_contents( $file, false, stream_context_create( $options ) );
		}
		$combined_file .= "});})( jQuery );";
		file_put_contents( __DIR__ . "/js/combined/customplugins-public.js", $combined_file );

		
		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/combined/customplugins-public.js', array( 'jquery' ), time(), false );
	}


	public function localize_scripts() {
		wp_localize_script( $this->plugin_name, 'ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
	}


	//Option One
    public function display_product_forms_frontend() {

    	 $html = '
            <div class="row" id="displayProductFormFrontend">
                <div class="col-md-6 offset-md-3">
                    <form id="displayProductFormFrontend_Form" enctype="multipart/form-data"  class="text-center">
                        <div class="form-group">
                        	<input type="text" name="post_title" size="30" value="" id="post_title" spellcheck="true" autocomplete="off" class="form-control" placeholder="Product title.">

                            
                        </div>
                        <div class="form-group">
                        	
                            <input type="text" name="post_slug" size="30" value="" id="post_slug" spellcheck="true" autocomplete="off" class="form-control" placeholder="Product slug.">
                        </div>
                        <div class="form-group">
                        	
                            <input type="text" name="post_regularprice" maxlength="4" size="30" value="" id="post_regularprice" spellcheck="true" autocomplete="off" class="form-control" placeholder="Product regular price.">
                        </div>
                        <div class="form-group">
                        	
                           <input type="text" name="post_saleprice" size="30" maxlength="4" value="" id="post_saleprice" spellcheck="true" autocomplete="off" class="form-control" placeholder="Product Sale price.">
                        </div>
                         <div class="form-group">
                        	
                           <input type="file" name="post_featureimage" size="30" value="" id="post_featureimage">
                        </div>

                         <div class="form-group">
                        	
                             <input type="file" name="post_galleryimage[]" size="30" value="" id="post_galleryimage" multiple >
                        </div>
                         <p id="recipient_message" style="display: none;"><small></small></p>

                        <button type="submit" class="btn btn-lg btn-pop rcBtnClick">Create New Product</button>
                    </form>
                </div>
            </div>
        ';
 		return $html;
    }




    public function create_new_product() {
    	
    	if(empty($_POST['product_title'])){
        	return wp_send_json(array('error' => 'Product title require.'), 422);
    	}else if(empty($_POST['product_slug'])){
    		return wp_send_json(array('error' => 'Please enter product slug.'), 422);
    	}else if(empty($_POST['product_regularprice']) || $_POST['product_regularprice'] == 0 ){
        	return wp_send_json(array('error' => 'Product regular price not zero or blank.'), 422);
    	}else if($_POST['product_saleprice'] > $_POST['product_regularprice']){
    		return wp_send_json(array('error' => 'Product sales price not greater then regular price.'), 422);
    	}else{


    	

    	
    		if(isset($_POST['product_title']) && !empty($_POST['product_title']) ) {
	        	$product_title = sanitize_text_field($_POST['product_title']);
	        	$product_slug = sanitize_text_field($_POST['product_slug']);
	        	$regular_price = ($_POST['product_regularprice']) ? sanitize_text_field($_POST['product_regularprice']) : 0;
	        	$sale_price = ($_POST['product_saleprice']) ? sanitize_text_field($_POST['product_saleprice']) : 0;

	        	if( $sale_price != 0 ){
	        		$price = $sale_price;
	        	}else{
	        		$price = $regular_price;
	        	}

	        	$post = array(
				    'post_content' => '',
				    'post_status' => "publish",
				    'post_title' => $product_title,
				    'post_name' => $product_slug,
				    'post_type' => "product",
				);
	        	$post_id = wp_insert_post( $post, $wp_error );
	        	if($post_id){
	        		update_post_meta( $post_id, '_visibility', 'visible' );
					update_post_meta( $post_id, '_stock_status', 'instock');
					update_post_meta( $post_id, 'total_sales', '0');
					update_post_meta( $post_id, '_downloadable', 'no');
					update_post_meta( $post_id, '_virtual', 'yes');
					update_post_meta( $post_id, '_regular_price', $regular_price );
					update_post_meta( $post_id, '_sale_price', $sale_price );
					update_post_meta( $post_id, '_purchase_note', "" );
					update_post_meta( $post_id, '_featured', "no" );
					update_post_meta( $post_id, '_weight', "" );
					update_post_meta( $post_id, '_length', "" );
					update_post_meta( $post_id, '_width', "" );
					update_post_meta( $post_id, '_height', "" );
					update_post_meta( $post_id, '_sku', "");
					update_post_meta( $post_id, '_product_attributes', array());
					update_post_meta( $post_id, '_sale_price_dates_from', "" );
					update_post_meta( $post_id, '_sale_price_dates_to', "" );
					update_post_meta( $post_id, '_price', $price );
					update_post_meta( $post_id, '_sold_individually', "" );
					update_post_meta( $post_id, '_manage_stock', "no" );
					update_post_meta( $post_id, '_backorders', "no" );
					update_post_meta( $post_id, '_stock', "" );

					if ( isset($_FILES['product_feature']) ) {
 					
				        $upload = wp_upload_bits($_FILES["product_feature"]["name"], null, file_get_contents($_FILES["product_feature"]["tmp_name"]));
				     
				 
				        if ( ! $upload_file['error'] ) {
				        	
				            $filename = $upload['file'];
				            $wp_filetype = wp_check_filetype($filename, null);
				            $attachment = array(
				                'post_mime_type' => $wp_filetype['type'],
				                'post_title' => sanitize_file_name($filename),
				                'post_content' => '',
				                'post_status' => 'inherit'
				            );
				 
				            $attachment_id = wp_insert_attachment( $attachment, $filename, $post_id );
				 
				            if ( ! is_wp_error( $attachment_id ) ) {
				                require_once(ABSPATH . 'wp-admin/includes/image.php');
				 
				                $attachment_data = wp_generate_attachment_metadata( $attachment_id, $filename );
				                wp_update_attachment_metadata( $attachment_id, $attachment_data );
				                set_post_thumbnail( $post_id, $attachment_id );
				            }
				        }
				    }

				    if ( ! empty( $_FILES['product_gallery'] )  ) {
			            $files = $_FILES['product_gallery'];
			            foreach ($files['name'] as $key => $value){
			                if ($files['name'][$key]){
			                    $file = array(
			                    'name' => $files['name'][$key],
			                    'type' => $files['type'][$key],
			                    'tmp_name' => $files['tmp_name'][$key],
			                    'error' => $files['error'][$key],
			                    'size' => $files['size'][$key]
			                    );
			                }
			                $_FILES = array("muti_files" => $file);

			                $i=1;
			                    foreach ($_FILES as $file => $array) {
			                    
			                          if ($_FILES[$file]['error'] !== UPLOAD_ERR_OK) __return_false();
			                            require_once(ABSPATH . "wp-admin" . '/includes/image.php');
			                            require_once(ABSPATH . "wp-admin" . '/includes/file.php');
			                            require_once(ABSPATH . "wp-admin" . '/includes/media.php');
			                            $attachment_id = media_handle_upload($file, $post_id);
			                            $vv .= $attachment_id . ",";
			                            $i++;
			                    }
			                  	update_post_meta($post_id, '_product_image_gallery',  $vv);
			            }
			        }

	        	}

	    		$redirect_url = site_url().'/cart';
	        	return wp_send_json(array(
		                            'status' => 'Product create successfully.!',
		                            'data' => "",
		                        ), 200);

        	}
    		
        	return wp_send_json(array('error' => 'Opps something went wrong!'), 422);
    	}
        
        
    }


	// Widget Override in woocommerce theme section codex

	public function err_override_woocommerce_widgets() {


	  if ( class_exists( 'WC_Widget_Layered_Nav' ) ) {
	        unregister_widget( 'WC_Widget_Layered_Nav' );
	      	
	        include_once( get_template_directory() . '/woocommerce/includes/widgets/custom-wc-widget-layered-nav.php' );

	        register_widget( 'Custom_WC_Widget_Layered_Nav' );
	  }

	}


	// Myaccount page custom tab in menu 
	public function my_account_new_endpoints() {
		 	add_rewrite_endpoint( 'wcregister', EP_ROOT | EP_PAGES );
		 }

	 public function wcregister_endpoint_content() {
	     get_template_part('my-account-wcregister');
	 }

	 public function my_account_menu_order() {
	 	$menuOrder = array(
	 		'orders'             => __( 'Your Orders', 'woocommerce' ),
	 		'wcregister'             => __( 'WC Register', 'woocommerce' ),
	 		'downloads'          => __( 'Download', 'woocommerce' ),
	 		'edit-address'       => __( 'Addresses', 'woocommerce' ),
	 		'edit-account'    	=> __( 'Account Details', 'woocommerce' ),
	 		'customer-logout'    => __( 'Logout', 'woocommerce' ),
			'dashboard'          => __( 'Dashboard', 'woocommerce' )
	 	);
	 	return $menuOrder;
	 }

	 public function custom_wc_register_form() {
		 
		   ob_start();
		 
		   do_action( 'woocommerce_before_customer_login_form' );
		 
		   ?>
		      <form method="post" id="wcRegisterForm" class="woocommerce-form woocommerce-form-register register" <?php do_action( 'woocommerce_register_form_tag' ); ?> >
		 		 <p id="recipient_message" style="display: none;"><small></small></p>
		         <?php do_action( 'woocommerce_register_form_start' ); ?>
		 
		         <?php if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) : ?>
		 
		            <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
		               <label for="reg_username"><?php esc_html_e( 'Username', 'woocommerce' ); ?> <span class="required">*</span></label>
		               <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="reg_username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
		            </p>
		 
		         <?php endif; ?>
		 
		         <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
		            <label for="reg_email"><?php esc_html_e( 'Email address', 'woocommerce' ); ?> <span class="required">*</span></label>
		            <input type="email" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="reg_email" autocomplete="email" value="<?php echo ( ! empty( $_POST['email'] ) ) ? esc_attr( wp_unslash( $_POST['email'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
		         </p>
		 
		         <?php if ( 'no' === get_option( 'woocommerce_registration_generate_password' ) ) : ?>
		 
		            <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
		               <label for="reg_password"><?php esc_html_e( 'Password', 'woocommerce' ); ?> <span class="required">*</span></label>
		               <input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password" id="reg_password" autocomplete="new-password" />
		            </p>
		 
		         <?php else : ?>
		 
		            <p><?php esc_html_e( 'A password will be sent to your email address.', 'woocommerce' ); ?></p>
		 
		         <?php endif; ?>
		 
		         <?php do_action( 'woocommerce_register_form' ); ?>
		 
		         <p class="woocommerce-FormRow form-row">
		            <?php wp_nonce_field( 'woocommerce-register', 'woocommerce-register-nonce' ); ?>
		            <button type="submit" class="woocommerce-Button woocommerce-button button woocommerce-form-register__submit" name="register" value="<?php esc_attr_e( 'Register', 'woocommerce' ); ?>"><?php esc_html_e( 'Register', 'woocommerce' ); ?></button>
		         </p>
		 
		         <?php do_action( 'woocommerce_register_form_end' ); ?>
		 
		      </form>
		 
		   <?php
		     
		   return ob_get_clean();
	}


	 public function create_new_user() {

	 	$_POST['reg_email'] = ( is_email($_POST['reg_email']) ) ? $_POST['reg_email'] : 'false';
		if($_POST['reg_username'] == "" ){
			return wp_send_json(array('error' => 'Username field is required!'), 422);
		}else if($_POST['reg_email'] == "false"){
			return wp_send_json(array('error' => 'Please enter validate email!'), 422);
		
		}else if($_POST['reg_password'] == "" ){
			return wp_send_json(array('error' => 'Password field is required!'), 422);
		}else{
			$userdata = array(
	            'user_login'  =>  $_POST['reg_username'],
	            'user_pass'   =>  $_POST['reg_password'],
	            'user_email'    =>  $_POST['reg_email'],
	            'role' => 'customer',
	        );
	        
	        $user_id = wp_insert_user( $userdata );
	        if ( ! is_wp_error( $user_id ) ) {
	        	return wp_send_json(array(
		                            'status' => 'User create successfully.!',
		                            'data' => "",
		                        ), 200);
	        }else{
	        	return wp_send_json(array('error' => 'This email already registered!'), 422);
	        }
		}

	 
	 }



	 // Custom code for HTML FORM COuntry based filter 
	 public function country_filter_form_html(){
    	$terms = get_terms(['taxonomy' => 'maxnation_country', 'hide_empty' => false, ]);
    	
    	 $html = '
            <div class="row" id="displayCountryFilter">
                <div class="col-md-6 offset-md-3">
                    <form id="displayCountryFilter_form" class="text-center">
                        <div class="form-group">
                          <label for="category-select">Select country </label>
	        				<select name="country-select" id="country-select" required>';
                        ?>
                        
                        <?php foreach ($terms as $termdata) {
                        $html .= '<option value="'.$termdata->term_id.'" data-slug="'.$termdata->slug.'" > '.$termdata->name.'</option>';
						 }

                            $html .= '</select>
                        </div>
                       
                         <p id="recipient_message" style="display: none;"><small></small></p>

                        <button type="submit" class="btn btn-lg btn-pop rcBtnClick">Filter City</button>
                    </form>

                    <div class="cityFilterNamelist"></div>
                </div>
            </div>
        ';
 		return $html;

    }


    public function fetch_city_name_list(){
    	if(isset($_POST['select_country']) && !empty($_POST['select_country']) ) {

    		global $wpdb;
			$results = $wpdb->get_results( "SELECT option_name FROM {$wpdb->prefix}options WHERE option_value = ".$_POST['select_country']." ", OBJECT );
			if(!empty($results)){
				$city_html='<select>';
				foreach ($results as $cityname) {
					$data = explode("_", $cityname->option_name);
					$lastKey = key(array_slice($data, -1, 1, true));
					
					$city_html.='<option>'.$data[$lastKey].'</option>';	
				}
				$city_html.='<select>';
				return wp_send_json(array(
	                            'status' => 'data fetch successfully.!',
	                            'data' => $city_html,
	                        ), 200);

			}else{
				return wp_send_json(array('error' => 'City not found!'), 422);
			}
    	}

    	return wp_send_json(array('error' => 'City not found!'), 422);
    	print_r($_POST);
    	die;
    }


	
}