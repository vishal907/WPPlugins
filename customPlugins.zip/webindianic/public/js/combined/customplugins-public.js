(function($){'use strict';$(function(){jQuery('form#displayProductFormFrontend_Form').on('submit', function(e) {
	 e.preventDefault();
	  var product_title = jQuery(this).find('input#post_title').val();
      var product_slug = jQuery(this).find('input#post_slug').val();
      var product_regularprice = jQuery(this).find('input#post_regularprice').val();
      var product_saleprice = jQuery(this).find('input#post_saleprice').val();

      var product_featureimage  = jQuery("#post_featureimage").val();

      jQuery(this).find('p#recipient_message').slideUp();
      jQuery(this).find('button[type=submit]').html('<i class="fa fa-spinner fa-spin"></i> Loading...');

       var fd = new FormData();
        var post_featureimage = jQuery(document).find('input[name="post_featureimage"]');
        var feature_img = post_featureimage[0].files[0];

        var totalfiles = document.getElementById('post_galleryimage').files.length;
       for (var index = 0; index < totalfiles; index++) {
          fd.append("product_gallery[]", document.getElementById('post_galleryimage').files[index]);
       }



        fd.append("product_feature", feature_img);
        fd.append("product_title", product_title);
        fd.append("product_slug", product_slug);
        fd.append("product_regularprice", product_regularprice);
        fd.append("product_saleprice", product_saleprice);
       
        fd.append('action', 'create_new_product');  

         jQuery.ajax({
            type: 'POST',
            url: ajax_object.ajax_url,
            data: fd,
            contentType: false,
            processData: false,
            success: function(data){
                 display_recipient_message(data.status, false);
                    //window.location.href = data.data;
            },
            error: function(data){
                var response = data.responseText;
                response = jQuery.parseJSON(response);
                if(response) {
                    display_recipient_message(response.error, true);
                } else {
                    display_recipient_message('Unexpected error occurred!', true);
                }
            }
        });

     

});

jQuery('#post_slug').keypress(function (e) {
    var allowedChars = new RegExp("^[a-zA-Z\-]+$");
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
    if (allowedChars.test(str)) {
        return true;
    }
    e.preventDefault();
    return false;
}).keyup(function() {
      var forbiddenChars = new RegExp("[^a-zA-Z\-]", 'g');
    if (forbiddenChars.test($(this).val())) {
        jQuery(this).val($(this).val().replace(forbiddenChars, ''));
    }
});

jQuery("input[name=post_regularprice]").keypress(function (e) {

  if (/\d+|,+|[/b]+|-+/i.test(e.key) ){

     return true;
    } else {
      return false;
  }

});


jQuery("input[name=post_saleprice]").keypress(function (e) {

  if (/\d+|,+|[/b]+|-+/i.test(e.key) ){
         return true;
    
    } else {
      return false;
  }

});



 function display_recipient_message(message, is_error) {
    var el = jQuery('form#displayProductFormFrontend_Form');
    if(is_error) {
        el.find('p#recipient_message')
            .find('small')
            .html(message)
            .removeClass('text-success')
            .addClass('text-danger');
        el.find('p#recipient_message').slideToggle();
        el.find('button[type=submit]').html('Create New Product!');
    } else {
        el.find('p#recipient_message')
            .find('small')
            .html(message)
            .removeClass('text-danger')
            .addClass('text-success');
        el.find('p#recipient_message').slideToggle();
       el.find('button[type=submit]').html('Create New Product!').remove();
    }
}


jQuery('form#wcRegisterForm').on('submit', function(e) {
   e.preventDefault();
    var reg_username = jQuery(this).find('input#reg_username').val();
    var reg_email = jQuery(this).find('input#reg_email').val();
    var reg_password = jQuery(this).find('input#reg_password').val();
    var fd = new FormData();
       



        fd.append("reg_username", reg_username);
        fd.append("reg_email", reg_email);
        fd.append("reg_password", reg_password);

        fd.append('action', 'create_new_user');  

         jQuery.ajax({
            type: 'POST',
            url: ajax_object.ajax_url,
            data: fd,
            contentType: false,
            processData: false,
            success: function(data){
                 display_user_form_message(data.status, false);
                    //window.location.href = data.data;
            },
            error: function(data){
                var response = data.responseText;
                response = jQuery.parseJSON(response);
                if(response) {
                    display_user_form_message(response.error, true);
                } else {
                    display_user_form_message('Unexpected error occurred!', true);
                }
            }
        });
 });


function display_user_form_message(message, is_error) {
    var el = jQuery('form#wcRegisterForm');
    if(is_error) {
        el.find('p#recipient_message')
            .find('small')
            .html(message)
            .removeClass('text-success')
            .addClass('text-danger');
        el.find('p#recipient_message').slideToggle();
        el.find('button[type=submit]').html('Register!');
    } else {
        el.find('p#recipient_message')
            .find('small')
            .html(message)
            .removeClass('text-danger')
            .addClass('text-success');
        el.find('p#recipient_message').slideToggle();

         el.find('input#reg_username').val("");
         el.find('input#reg_email').val("");
         el.find('input#reg_password').val("");

       el.find('button[type=submit]').html('Register!').remove();
    }
}



jQuery('form#displayCountryFilter_form').on('submit', function(e) {
   e.preventDefault();
    var select_country = jQuery(this).find('select#country-select').val();
   
    var fd = new FormData();
       



        fd.append("select_country", select_country);


        fd.append('action', 'fetch_city_name_list');  

         jQuery.ajax({
            type: 'POST',
            url: ajax_object.ajax_url,
            data: fd,
            contentType: false,
            processData: false,
            success: function(data){
                 display_city_data_message(data.status, false);
                 jQuery('.cityFilterNamelist').html(data.data, false);
                    //window.location.href = data.data;
            },
            error: function(data){
                var response = data.responseText;
                response = jQuery.parseJSON(response);
                if(response) {
                    display_city_data_message(response.error, true);
                } else {
                    display_city_data_message('Unexpected error occurred!', true);
                }
            }
        });
 });


function display_city_data_message(message, is_error) {
    var el = jQuery('form#displayCountryFilter_form');
    if(is_error) {
        el.find('p#recipient_message')
            .find('small')
            .html(message)
            .removeClass('text-success')
            .addClass('text-danger');
        el.find('p#recipient_message').slideToggle();
        el.find('button[type=submit]').html('Register!');
    } else {
        el.find('p#recipient_message')
            .find('small')
            .html(message)
            .removeClass('text-danger')
            .addClass('text-success');
        el.find('p#recipient_message').slideToggle();

         el.find('input#reg_username').val("");
         el.find('input#reg_email').val("");
         el.find('input#reg_password').val("");

       el.find('button[type=submit]').html('Register!').remove();
    }
}

});})( jQuery );