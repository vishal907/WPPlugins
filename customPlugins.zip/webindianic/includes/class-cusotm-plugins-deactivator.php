<?php


class custom_Plugins_Deactivator {


	public static function deactivate() {
	
	}

}
