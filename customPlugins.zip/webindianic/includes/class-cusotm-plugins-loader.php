<?php

class custom_Plugins_Loader {


	protected $actions;

	
	protected $filters;

   
	protected $meta_boxes;

   
    protected $short_codes;

	
	public function __construct() {

		$this->actions = array();
		$this->filters = array();
		$this->meta_boxes = array();
        $this->short_codes = array();

	}

	
	public function add_action( $hook, $component, $callback, $priority = 10, $accepted_args = 1 ) {
		$this->actions = $this->add( $this->actions, $hook, $component, $callback, $priority, $accepted_args );
	}


	public function add_filter( $hook, $component, $callback, $priority = 10, $accepted_args = 1 ) {
		$this->filters = $this->add( $this->filters, $hook, $component, $callback, $priority, $accepted_args );
	}

    
	public function add_meta_box($id, $component, $callback, $screen, $context, $priority, $title) {
        $tmp = array(
            'id' => $id,
            'title' => $title,
            'callback' => array( $component, $callback),
            'screen' => $screen,
            'context' => $context,
            'priority' => $priority
        );

        $this->meta_boxes[] = $tmp;
    }

  
    public function add_shortcode($name, $component, $callback) {
        $this->short_codes[] = array(
            'name' => $name,
            'component' => $component,
            'callback' => $callback
        );
    }

	
	private function add( $hooks, $hook, $component, $callback, $priority, $accepted_args ) {

		$hooks[] = array(
			'hook'          => $hook,
			'component'     => $component,
			'callback'      => $callback,
			'priority'      => $priority,
			'accepted_args' => $accepted_args
		);

		return $hooks;

	}

	public function add_all_meta_boxes() {
        foreach ($this->meta_boxes as $hook) {
            add_meta_box($hook['id'], $hook['title'], $hook['callback'], $hook['screen'], $hook['context'], $hook['priority'], null);
            //remove_meta_box( $hook['id'], $hook['screen'], $hook['context'] );
        }
    }

	
	public function run() {

		foreach ( $this->filters as $hook ) {
			add_filter( $hook['hook'], array( $hook['component'], $hook['callback'] ), $hook['priority'], $hook['accepted_args'] );
		}

		foreach ( $this->actions as $hook ) {
			add_action( $hook['hook'], array( $hook['component'], $hook['callback'] ), $hook['priority'], $hook['accepted_args'] );
		}

        foreach ($this->short_codes as $short_code) {
            add_shortcode($short_code['name'], array($short_code['component'], $short_code['callback']));
        }

		add_action('add_meta_boxes', array($this, 'add_all_meta_boxes'), 30);

	}

}
