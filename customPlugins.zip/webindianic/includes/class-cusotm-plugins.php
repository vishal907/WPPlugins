<?php

class custom_Plugins {


	protected $loader;


	protected $plugin_name;

	protected $version;
	
	protected static $_instance;

	public $dates;
	
	public $public;

	public function __construct() {
		if ( defined( 'PLUGIN_VERSION' ) ) {
			$this->version = PLUGIN_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'custom-plugins';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

	}

	
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	
	private function load_dependencies() {


		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-cusotm-plugins-loader.php';

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-cusotm-plugins-i18n.php';
		
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-cusotm-plugins-admin.php';

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-cusotm-plugins-public.php';

		$this->loader = new custom_Plugins_Loader();

	}

	
	private function set_locale() {

		$plugin_i18n = new custom_Plugins_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}


	private function define_admin_hooks() {
		$plugin_admin = new custom_Plugins_Admin( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
		$this->loader->add_action( 'init', $plugin_admin, 'max_nation_custom_post_type', 0 );

		$this->loader->add_action('maxnation_city_add_form_fields', $plugin_admin,'add_extra_fields_to_maxnation_city');

		
		$this->loader->add_action('create_maxnation_city', $plugin_admin ,'save_extra_taxonomy_fields');
		$this->loader->add_action('maxnation_city_edit_form_fields',$plugin_admin ,'edit_extra_fields_for_maxnation_city');

		$this->loader->add_action('edit_maxnation_city', $plugin_admin ,'save_extra_taxonomy_fields');


	
	}

	private function define_public_hooks() {
		$plugin_public = new custom_Plugins_Public( $this->get_plugin_name(), $this->get_version() );
		
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
        $this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );
        $this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'localize_scripts' );

        $this->loader->add_shortcode('displayProductFormFrontend', $plugin_public, 'display_product_forms_frontend');
		 $this->loader->add_action( 'wp_ajax_create_new_product', $plugin_public, 'create_new_product' );
         $this->loader->add_action( 'wp_ajax_nopriv_create_new_product', $plugin_public, 'create_new_product' );


         $this->loader->add_action('widgets_init', $plugin_public, 'err_override_woocommerce_widgets', 15 );



        $this->loader->add_action( 'init', $plugin_public, 'my_account_new_endpoints' ); 
		$this->loader->add_action( 'woocommerce_account_wcregister_endpoint', $plugin_public, 'wcregister_endpoint_content' );

		$this->loader->add_filter ( 'woocommerce_account_menu_items',$plugin_public, 'my_account_menu_order' );

		$this->loader->add_shortcode ( 'WCREGISTERFORM',$plugin_public, 'custom_wc_register_form' );

    	
    	$this->loader->add_action( 'wp_ajax_create_new_user', $plugin_public, 'create_new_user' );
        $this->loader->add_action( 'wp_ajax_nopriv_create_new_user', $plugin_public, 'create_new_user' );



        $this->loader->add_shortcode ( 'COUNTRYFILTERHTML',$plugin_public, 'country_filter_form_html' );
        
        $this->loader->add_action( 'wp_ajax_fetch_city_name_list', $plugin_public, 'fetch_city_name_list' );
        $this->loader->add_action( 'wp_ajax_nopriv_fetch_city_name_list', $plugin_public, 'fetch_city_name_list' );

 
	}




	public function run() {
		$this->loader->run();
	}

	
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	
	public function get_loader() {

		return $this->loader;
	}

	
	public function get_version() {
		return $this->version;
	}

}
