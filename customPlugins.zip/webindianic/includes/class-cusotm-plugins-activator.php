<?php

class custom_Plugins_Activator {


	public static function activate() {
 		
	}

}
