<?php

class custom_Plugins_Admin {

	
	private $plugin_name;

	
	private $version;

	
	public function __construct( $plugin_name, $version ) {
		$this->plugin_name = $plugin_name;
		$this->version = $version;
	}

	
	public function enqueue_styles() {
			$options = array(
			"ssl" => array(
				"verify_peer"      => false,
				"verify_peer_name" => false
			)
		);

		$files         = glob( __DIR__ . '/css/*.css' );
		$combined_file = '';
		foreach ( $files as $file ) {
			$combined_file .= file_get_contents( $file, false, stream_context_create( $options ) );
		}
		file_put_contents( __DIR__ . "/css/combined/customplugins-admin.css", $combined_file );
		// only the line below should be in production
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/combined/customplugins-admin.css', array(), 0.52, 'all' );
	}

	
	public function enqueue_scripts() {
			wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/combined/customplugins-admin.js', array( 'jquery' ), 0.33, false );
	}

	public function max_nation_custom_post_type(){
		 $labels = array(
		    'name'                => __( 'MixNation' ),
		    'singular_name'       => __( 'MixNation'),
		    'menu_name'           => __( 'MixNation'),
		    'parent_item_colon'   => __( 'Parent MixNation'),
		    'all_items'           => __( 'All MixNations'),
		    'view_item'           => __( 'View MixNation'),
		    'add_new_item'        => __( 'Add New MixNation'),
		    'add_new'             => __( 'Add New'),
		    'edit_item'           => __( 'Edit MixNation'),
		    'update_item'         => __( 'Update MixNation'),
		    'search_items'        => __( 'Search MixNation'),
		    'not_found'           => __( 'Not Found'),
		    'not_found_in_trash'  => __( 'Not found in Trash')
		  );
		  $args = array(
		      'label'               => __( 'MixNations'),
		      'description'         => __( 'Best Crunchify Nutritionals'),
		      'labels'              => $labels,
		      'supports'            => array( 'title', 'custom-fields'),
		      'public'              => true,
		      'hierarchical'        => false,
		      'show_ui'             => true,
		      'show_in_menu'        => true,
		      'show_in_nav_menus'   => true,
		      'show_in_admin_bar'   => true,
		      'has_archive'         => true,
		      'can_export'          => true,
		      'exclude_from_search' => false,
		      'yarpp_support'       => true,
		      'publicly_queryable'  => true,
		      'supports' => array( 'title', 'thumbnail'),
		      'capability_type'     => 'page'
		  );
		  register_post_type( 'mixNations', $args );



		  $country_labels = array(
		    'name'              => _x( 'Country', 'taxonomy general name' ),
		    'singular_name'     => _x( 'Country', 'taxonomy singular name' ),
		    'search_items'      => __( 'Search Countries' ),
		    'all_items'         => __( 'All Countries' ),
		    'parent_item'       => __( 'Parent Country' ),
		    'parent_item_colon' => __( 'Parent Country:' ),
		    'edit_item'         => __( 'Edit Country' ), 
		    'update_item'       => __( 'Update Country' ),
		    'add_new_item'      => __( 'Add New Country' ),
		    'new_item_name'     => __( 'New Country' ),
		    'menu_name'         => __( 'Countries' ),
		  );
		  $args = array(
		    'labels' => $country_labels,
		    'hierarchical' => true,
		  );
		  register_taxonomy( 'maxnation_country', 'mixnations', $args );

		  $city_labels = array(
		    'name'              => _x( 'City', 'taxonomy general name' ),
		    'singular_name'     => _x( 'City', 'taxonomy singular name' ),
		    'search_items'      => __( 'Search Cities' ),
		    'all_items'         => __( 'All Cities' ),
		    'parent_item'       => __( 'Parent City' ),
		    'parent_item_colon' => __( 'Parent City:' ),
		    'edit_item'         => __( 'Edit City' ), 
		    'update_item'       => __( 'Update City' ),
		    'add_new_item'      => __( 'Add New City' ),
		    'new_item_name'     => __( 'New City' ),
		    'menu_name'         => __( 'Cities' ),

		  );
		  $args = array(
		    'labels' => $city_labels,
		    'hierarchical' => false,
		    'show_option_none' => true,
		  

		  );
		  register_taxonomy( 'maxnation_city', 'mixnations', $args );

		

	}


	public function add_extra_fields_to_maxnation_city($taxonomy_name){
		
		$terms = get_terms(['taxonomy' => 'maxnation_country', 'hide_empty' => false, ]);
		
		

	    ?>

	    <div class="form-field">
	        <label for="category-select">Select country </label>
	        <select name="country-select" id="country-select" required>
	         <?php foreach ($terms as $termdata) { ?>
	         	<option value="<?php echo $termdata->term_id; ?>"> <?php echo $termdata->name; ?> </option>
	         <?php  } ?>
	        
	        </select>
	       
	    </div>
	   
	    <?php
	}


	public function save_extra_taxonomy_fields($term_id){
	
		    //collect all term related data for this new taxonomy
		    $term_item = get_term($term_id,'maxnation_city');
		    $term_slug = $term_item->slug;

		//collect our custom fields
		
		$term_category_select = sanitize_text_field($_POST['country-select']); 
			 
		 //save our custom fields as wp-options
	
		update_option('term_maxnation_country_select_' . $term_slug, $term_category_select);


	}


	public function edit_extra_fields_for_maxnation_city($term){

	    $term_slug = $term->slug;
 	    $term_category_select = get_option('term_maxnation_country_select_' . $term_slug); 
	    $terms = get_terms(['taxonomy' => 'maxnation_country', 'hide_empty' => false, ]);
   ?>
	   
	    <tr class="form-field">
	        <th valign="top" scope="row">
	            <label for="category-select"> Country select field </label>
	        </th>
	        <td>
	        	 <select name="country-select" id="country-select" required>
		         <?php foreach ($terms as $termdata) {  ?>
		         	<option value="<?php echo $termdata->term_id; ?>" <?php if($term_category_select==$termdata->term_id){ echo 'selected';}?> > <?php echo $termdata->name; ?> </option>
		         <?php  } ?>
		        
		        </select>

	          
	        </td>
	    </tr>
	  
	    <?php
	}



}
