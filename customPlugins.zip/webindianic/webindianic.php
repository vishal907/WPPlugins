<?php

/**
 * The plugin bootstrap file
 *
 *
 * @link              www.customplugins.com
 * @since             1.0.0
 * @package           Custom_Plugins
 *
 * @wordpress-plugin
 * Plugin Name:       cusotm-plugins
 * Plugin URI:        www.cusotmplugins.com
 * Description:       Fully Customize plugins.
 * Version:           1.0.0
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       cusotm-plugins
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

define( 'PLUGIN_VERSION', '1.0.0' );


function activate_custom_plugins() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-cusotm-plugins-activator.php';
	custom_Plugins_Activator::activate();
}


function deactivate_custom_plugins() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-cusotm-plugins-deactivator.php';
	custom_Plugins_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_custom_plugins' );
register_deactivation_hook( __FILE__, 'deactivate_custom_plugins' );


require plugin_dir_path( __FILE__ ) . 'includes/class-cusotm-plugins.php';


function run_custom_Plugins() {

	$plugin = new custom_Plugins();
	$plugin->run();

}
run_custom_Plugins();


function iof() {
	return custom_Plugins::instance();
}

$GLOBALS['iof'] = iof();
